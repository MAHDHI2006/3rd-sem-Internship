import React from 'react';
class ClassComponent extends React.Component {
    render() {
        return (
            <div>
                <h1>This is a Class Component</h1>
            </div>
        );
    }
}
export default ClassComponent; 