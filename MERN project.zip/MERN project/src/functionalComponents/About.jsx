const About = () => {   
    return(
        <div>
            <h2>This is About page</h2>
            <hr/>
            <p>For MERN stack</p>
        </div>
    );
}   
export default About;