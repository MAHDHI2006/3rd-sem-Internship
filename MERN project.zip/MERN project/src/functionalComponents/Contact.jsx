const Contact = () => {  
    return(
        <div>
            <h2>This is Contact page</h2>
        </div>
    );
}   
export default Contact;